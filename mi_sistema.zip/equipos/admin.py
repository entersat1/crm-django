#  ARCHIVO COMENTADO - Los equipos se manejan en �rdenes de Taller
# from django.contrib import admin
# from .models import Equipo

# admin.site.register(Equipo)
